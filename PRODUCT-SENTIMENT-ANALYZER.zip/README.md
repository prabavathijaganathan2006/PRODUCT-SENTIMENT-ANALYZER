# Product Sentiment Analyzer

## Description

The Product Sentiment Analyzer is a web application that scrapes product reviews from Flipkart using Selenium and analyzes the sentiment of each review using TextBlob.

## Features

* Product Search
* Review Scraping
* Sentiment Analysis
* Review Dashboard
* Word Cloud
* Flask Backend
* React Frontend

## Technologies Used

* React.js
* Flask
* Selenium
* TextBlob
* Python
* JavaScript

## How to Run

### Backend

```bash
cd backend
py app.py
```

### Frontend

```bash
cd frontend
npm install
npm start
```

## Developed By

Team Members


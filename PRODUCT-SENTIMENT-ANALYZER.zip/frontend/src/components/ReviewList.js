import { useEffect, useState } from "react";

function ReviewList() {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:5000/reviews")
      .then((res) => res.json())
      .then((data) => setReviews(data))
      .catch((err) => console.log(err));
  }, []);

  return (
    <div>
      <h2>Reviews</h2>

      <ul>
        {reviews.map((item, index) => (
          <li key={index}>
            <b>{item.sentiment}</b> - {item.review}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ReviewList;
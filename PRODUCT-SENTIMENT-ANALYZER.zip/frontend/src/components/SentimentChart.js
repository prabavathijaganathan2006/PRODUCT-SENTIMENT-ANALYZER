import { useEffect, useState } from "react";

function SentimentChart() {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:5000/reviews")
      .then((res) => res.json())
      .then((data) => setReviews(data));
  }, []);

  const positive = reviews.filter(
    (r) => r.sentiment === "Positive"
  ).length;

  const neutral = reviews.filter(
    (r) => r.sentiment === "Neutral"
  ).length;

  const negative = reviews.filter(
    (r) => r.sentiment === "Negative"
  ).length;

  return (
    <div>
      <h2>Sentiment Analysis</h2>

      <p>😊 Positive : {positive}</p>
      <p>😐 Neutral : {neutral}</p>
      <p>😞 Negative : {negative}</p>
    </div>
  );
}

export default SentimentChart;
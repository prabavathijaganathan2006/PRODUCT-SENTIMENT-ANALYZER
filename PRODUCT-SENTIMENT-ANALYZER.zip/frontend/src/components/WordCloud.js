import { useEffect, useState } from "react";

function WordCloud() {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:5000/reviews")
      .then((res) => res.json())
      .then((data) => setReviews(data))
      .catch((err) => console.log(err));
  }, []);

  return (
    <div>
      <h2>Word Cloud</h2>

      {reviews.map((item, index) => (
        <span key={index} style={{ marginRight: "15px" }}>
          {item.review}
        </span>
      ))}
    </div>
  );
}

export default WordCloud;